import matplotlib.pyplot as plt
import re, numpy as np


def star_scatter_plot(x, y, z, parts = None, whole = None):
    '''
    Generate a scatter plot by supplying a list of x, y, and z values.

    Parameters:
    ----------
        x : list
            The list of x values.
        y : list
            The list of y values.
        z : list
            The list of z values.
        parts : list
            list of values (like form.scalar factor) associated with each star
        whole : number
            the whole number to compare to each part

    '''

    ax = plt.axes(projection='3d')
    fig = plt.gcf()
    scatter = None

    if parts is not None and whole is not None:
        colors = np.array([part / whole for part in parts])  # Calculate color based on the ratio
        colors = np.where(colors > 0.5, 'green', 'blue')
        # Generate a scatter plot with the specified colors
        # vmin = 0, vmax = 0.5
        scatter = ax.scatter3D(x, y, z, c=colors, cmap='Blues')
    else:
        # Generate a scatter plot without color mapping
        scatter = ax.scatter3D(x, y, z)

    fig.colorbar(scatter)

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')
    ax.set_title('3D Scatter Plot')
    ax.grid(False)
    plt.show()

def pie_chart(values, labels):
    '''
    Generate a pie chart by supplying a list of labels and values.

    Parameters:
    ----------
        labels : list
            The list of labels.
        values : list
            The list of values.
    '''
    sizes = [count for count in values if count > 3]
    explode = [0.1 if size == max(sizes) else 0 for size in sizes]
    fig, ax = plt.subplots()
    ax.pie(sizes, labels=labels, autopct='%1.1f%%', explode=explode)
    ax.legend(loc="best")
    plt.show()

def graph(x, y, title = None, x_label = None, y_label = None, windowTitle = "Figure", showLine = True):
    '''
    Generate a 2d graph with given x and y values.

    Parameters:
    ----------
        labels : list
            The list of labels.
        values : list
            The list of values.
    '''
    # Auto generate x_label and y_label with the given title
    if title is not None:
        pattern = r'\s*(vs\.|versus|vs)\s*'
        match = re.search(pattern, title, re.IGNORECASE)
        if match:
            before = title[:match.start()].strip()
            after = title[match.end():].strip()
            x_label = x_label if x_label is not None else after
            y_label = y_label if y_label is not None else before


    # Create a line plot
    if(showLine):
        #find line of best fit
        a, b = np.polyfit(x, y, 1)    
        # 'b.-' - This parameter is a shorthand notation to specify the line color, marker style, and line style of the plot.
        plt.plot(x, y, 'b.-')
    else:
        plt.scatter(x,y)

    # Set the x and y axis labels
    plt.xlabel(x_label if x_label is not None else 'X')
    plt.ylabel(y_label if y_label is not None else 'Y')
    # Set the title of the graph
    plt.title(title if title is not None else 'Y vs X')
    fig = plt.gcf()
    fig.canvas.manager.set_window_title(windowTitle)
    # Display the graph
    plt.show()

def plot_gas_dens(part,data,header,runname,bins=70,ind=0,thick=None,vmin=None,vmax = None):
    """

    """
    import scipy

    ################### LOAD PARTICLE INFO #########################
    h = header['hubble']

    ###########################################

    maincen = np.array([data.field('Xc(6)')[ind]/h,data.field('Yc(7)')[ind]/h,data.field('Zc(8)')[ind]/h])
    mainrvir = data.field('Rvir(12)')[ind]/h

    if thick is None:
        thick = mainrvir

    pos = part['gas']['position'][:]
    pos = pos - maincen
    mass = part['gas']['mass'][:]


    x = pos[:,0] 
    y = pos[:,1] 
    z = pos[:,2] 

    x = x[np.abs(z) < thick]
    y = y[np.abs(z) < thick]
    mass = mass[np.abs(z) < thick]

    mass = mass[((np.abs(x)<=thick)&(np.abs(y)<=thick))]
    xx = x[((np.abs(x)<=thick)&(np.abs(y)<=thick))]
    yy = y[((np.abs(x)<=thick)&(np.abs(y)<=thick))]

    ret = scipy.stats.binned_statistic_2d(xx, yy, mass, statistic='sum', bins=bins)

    # Calc area per bin
    dx = np.diff(ret.x_edge)
    dy = np.diff(ret.y_edge)
    area = dx[:,  None] * dy


    plt.clf()
    fig = plt.figure(1, figsize = (10,10))
    ax1 = fig.add_subplot(1,1,1)
    ax1.patch.set_facecolor('black')

    if vmin is None:
        plt.imshow(np.log10(ret.statistic/area), cmap='seismic', interpolation='gaussian')
    else:
        plt.imshow(np.log10(ret.statistic/area), cmap='seismic', interpolation='gaussian',vmin = vmin,vmax = vmax)

    cbar = plt.colorbar()
    cbar.ax.setylabel(r'$\rm log ,\Sigma ,(M{\odot}/pc^2)$', fontsize = 22)
    plt.savefig("FDensHist%s%i%i.png"%(runname,thick,bins))
