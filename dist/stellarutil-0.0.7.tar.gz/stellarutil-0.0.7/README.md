# stellarutil
A utility package for: gizmo_analysis, matplotlib, and other libraries. Made for CPP Fire Squad.

## Installation

First install dependencies:
```shell
pip3 install astropy matplotlib numpy h5py pandas scipy
```
Then, run the following command:
```shell
pip3 install git+https://github.com/CPP-FIRE-Squad/stellarutil.git
```